import React from 'react';

import classes from './Input.css';
import Spinner from '../../../UI/Spinner/Spinner';

const Input = (props) => {

    let styleClasses = [classes.InputElement];
    let inputElement = null;
    let showSpinner = props.showSpinner;
    if(props.valid && props.visited){
        styleClasses.push(classes.Invalid)
    }
    switch(props.elementType){
        case('input'):
            inputElement = <input 
                                className = {styleClasses.join(' ')} 
                                {...props.elementConfig}
                                value = {props.value} 
                                onChange = {props.changed}/>;
            break;
        default:
           inputElement = <input 
                                className = {classes.InputElement} 
                                {...props.elementConfig}
                                value = {props.value} 
                                onChange = {props.changed} />;
           break;
    }
    
    let spin = null;
    if(showSpinner && props.spin){
        spin = <Spinner />;
    }


    return (
        <div className = {classes.Input}>
            {inputElement}
            {spin}
        </div>
    );
}

export default Input;