import React from 'react';

import classes from './Inputs.css';

const Inputs = (props) => {
    let elementTemplate;
    switch(props.elementType){
        case('input'):
            elementTemplate = <input
                                id = {props.id}  
                                className = {classes.InputElement}
                                value = {props.value}
                                {...props.elementConfig}
                                onChange = {props.changed}/>;
            break;
        case('textarea'):
        elementTemplate = <textarea 
                                id = {props.id} 
                                className = {classes.TextElement} 
                                value = {props.value}
                                {...props.elementConfig}
                                onChange = {props.changed}
                                rows = "15"></textarea>;
            break; 
        default:
        elementTemplate = <input />;
            break;
    }
    return elementTemplate;
}   

export default Inputs;