import React from 'react';


import classes from './CatagoryBoxes.css';

const CatagoryBoxes = (props) => {
    return (
        <div style = {{backgroundColor: props.color}} className = {classes.CatagoryBox}>
                    <div className = {classes.CatagoryIcon}>
                       <span className = {[props.icon,classes.CatagoryLogo].join(' ')}></span>
                    </div>
                    <div className = {classes.CatagoryDetails}>
                       <p className = {classes.CatagoryType}>{props.name}</p>
                       <p className = {classes.CatagoryCount}>12<span className = {classes.Mails}> Mails</span></p>
                       <div className = {classes.Range}></div>
                       <p className = {classes.CatagoryPercent}><b>50%</b> of Total Mails</p>
                    </div>
        </div>
    );
}

export default CatagoryBoxes;