import React from 'react';

import classes from './Stars.css';

const Stars = (props) => {
    let starTemplate;
    switch(props.startType){
        case('filled'):
            starTemplate = <span className = {["fa fa-star",classes.Stars].join(' ')}></span>;
            break;
        case('unfilled'):
            starTemplate = <span className = {["fa fa-star-o",classes.Stars].join(' ')}></span>;
            break;
        default:
            starTemplate = <span className = {["fa fa-star-o",classes.Stars].join(' ')}></span>;
            break;
    }
    return starTemplate;
}

export default Stars;