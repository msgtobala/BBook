import React from 'react';
import { Link } from 'react-router-dom';

import classes from './DashboardBoxes.css';

const DashboardBoxes = (props) => {
    return (
        <div style = {{backgroundColor: props.color}} className = {classes.DashboardBox}>
                    <div className = {classes.Details}>
                       <div className = {classes.Detail}>
                         <p className = {classes.Number}>{props.count}</p>
                         <p className = {classes.Catagory}>{props.name}</p>
                       </div>
                       <div className = {classes.LogoIcon}>
                          <span className = {[props.icon,classes.MailIcons].join(' ')}></span>
                        </div>
                    </div>
                    <Link to = {props.toLink} className = {classes.MoreInfo}>
                        <span>More Info </span>
                        <span className = {["fa fa-arrow-circle-right",classes.MoreLogo].join(' ')}></span>
                    </Link>
        </div>
    );
}

export default DashboardBoxes;