import React from 'react';
import { withRouter } from 'react-router';


import classes from './MessageElement.css';

const MessageElement = (props) => {
    return (
        <div className={classes.Mails}
             onMouseEnter = {props.enter}
             onMouseLeave = {props.leave}>
            <label className={[classes.container, classes.check_title].join(' ')}>
                <input type="checkbox" className={classes.agree} />
                <span className={classes.checkmark}></span>
            </label>
            <span className={[props.icon, classes.Stars].join(' ')} onClick = {props.starClicked}></span>
            <p className = {classes.From} onClick = {props.mailClicked}>{props.from}</p>
            <p className={classes.Subject} onClick = {props.mailClicked}>{props.subject}</p>
            <p className={classes.Body} onClick = {props.mailClicked}>
                {props.body}
            </p>
            <span className = {["fa fa-trash",classes.Trash].join(' ')} 
                  style = {{visibility: props.displayDel === true ? 'visible':'hidden'}}
                  onClick = {props.deleteMail}></span>
        </div>
    );
}

export default withRouter(MessageElement);