import React from 'react';
import { NavLink } from 'react-router-dom';

import classes from './CatagoryElements.css';

const CatagoryElements = (props) => {
    return (
        <NavLink to = {props.toLink} className = {classes.CatagoryElement}>
            <p><span style = {{color: props.color}}className = {[props.icon,classes.Icon].join(' ')}></span> {props.name}</p>
        </NavLink>
    );
}

export default CatagoryElements;