import React from 'react';
import { NavLink } from 'react-router-dom';

import classes from './FolderElement.css';

const FolderElement = (props) => {
    return (
        <NavLink to = {props.toLink} className = {classes.FolderElement}>
            <p><span className = {[props.icon,classes.Icon].join(' ')}></span> {props.name}</p>
            <div className = {classes.Count}>12</div>
        </NavLink>
    );
}

export default FolderElement;