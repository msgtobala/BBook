import React from 'react';
import { NavLink } from 'react-router-dom';

import classes from './NavigationItems.css';
const NavigationItems = (props) => {
    return (
          <NavLink
                 to = {props.toLink} 
                 className = {classes.Navigations}>
                  <span className = {[props.icon, classes.Icons].join(' ')}></span>{props.name}
          </NavLink>
    );
}

export default NavigationItems;