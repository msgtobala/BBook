import React from 'react';


import classes from './Sidebar.css';
import Avatar from '../../../assets/Images/avatar.png';
import NavigationItems from './NavigationItems/NavigationItmes';
import Catagories from './Catagories/Catagories';

const Sidebar = (props) => {
    const navigations = props.navigation;
    const catagories = props.catagory;
    let navigationTemplate;
    let catagoryTemplate;
    navigationTemplate = (
        navigations.map(ele=>{
            return <NavigationItems
                            key = {ele.name} 
                            icon = {ele.icon}
                            name = {ele.displayName}
                            toLink = {ele.to}/>
        })
    );
    catagoryTemplate = (
        catagories.map(ele=>{
            return <Catagories
                            key = {ele.catagory}
                            icon = {ele.icon} 
                            name = {ele.displayName}
                            toLink = {ele.to}
                            color = {ele.color}/>
        })  
    );
    return (
        <div className = {classes.Sidebar}>
            <div className = {classes.Bmail}>BMAIL</div>
            <div className = {classes.Namecard}>
                <div className = {classes.Avatar}>
                     <img className = {classes.AvatarImage} src = {Avatar}  alt = "avatar"/>
                </div>
                <div className = {classes.NameDetails}>
                    <p className = {classes.Name}>Balaji Venkatraman</p>
                    <div className = {classes.dot}></div>
                    <span className = {classes.Online}>
                            Online
                    </span>
                </div>
            </div>
            <div className = {classes.InputBox}>
               <input 
                    type = "text" 
                    className = {classes.Search}
                    placeholder = "Search..."/>
                <span className = {['fa fa-search',classes.searchIcon].join(' ')}></span>
            </div>
            <div className = {classes.MainNavigation}>MAIN NAVIGATION</div>
            <div className = {classes.Navigation}>
                {navigationTemplate}
            </div>
            <div className = {classes.MainNavigation}>CATAGORIES</div>
            {catagoryTemplate}
        </div>
    );
}

export default Sidebar;