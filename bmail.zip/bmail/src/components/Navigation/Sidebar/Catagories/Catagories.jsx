import React from 'react';
import { NavLink } from 'react-router-dom';

import classes from './Catagories.css';
const Catagories = (props) => {
    return (
        <NavLink
                 to = {props.toLink} 
                 className = {classes.Catagories}>
                  <span
                    style = {{color: props.color}} 
                    className = {[props.icon, classes.Icons].join(' ')}></span>{props.name}
          </NavLink>
    );
}

export default Catagories;