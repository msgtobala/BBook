import React from 'react';

import classes from './Layout.css';
import Sidebar from '../../components/Navigation/Sidebar/Sidebar';
// import Footer from '../../Shared/Footer/Footer';
import Header from '../../Shared/Header/Header';

const Layout = (props) => {
    return (
        <div>
            <div className = {classes.Layout}>
                <Sidebar 
                    navigation = {props.navigation}
                    catagory = {props.catagories}/>
                 <div className = {classes.MainContent}>
                    <Header
                        notificationlinks = {props.notificationlinks}
                        settings = {props.cogs}/>
                    {props.children}
                </div>
                {/* <Footer /> */}
            </div>
        </div>
    );
}

export default Layout;