import React from 'react';

import Aux from '../../hoc/Aux';
import Header from '../../Shared/Land-Header/Land-Header';
import classes from './Layout.css';

const layout = (props) => {
    return (
        <Aux>
            <Header/>
            <main className = {classes.Layout}>
                {props.children}
             </main>
        </Aux>
    );
}

export default layout;