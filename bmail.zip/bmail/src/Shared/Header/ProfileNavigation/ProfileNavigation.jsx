import React from 'react';

import classes from './ProfileNavigation.css';
import Avatar from '../../../assets/Images/avatar.png';

const ProfileNavigation = () => {
    return (
        <div className = {classes.ProfileNavigation}>
            <div className = {classes.Avatar}>
                <img className = {classes.AvatarImage} src = {Avatar} alt = "user_avatar"/>
            </div>
            <div className = {classes.UserName}>
                <p className = {classes.User}>Balaji Venkatraman</p>
            </div>
        </div>
    );
}

export default ProfileNavigation;