import React from 'react';

import classes from './Header.css';
import SideNavigation from './SideNavigation/SideNavigation';
import ProfileNavigation from './ProfileNavigation/ProfileNavigation';

const Header = (props) => {
    let cogs = props.settings[0].icon;
    let navigationArray = props.notificationlinks;
    let SideNavigationTemplate = (
        navigationArray.map(ele=>(
                <SideNavigation 
                            key = {ele.icon}
                            icon = {ele.icon}
                            toLink = {ele.to}/>
        ))
    );
    return (
        <div className = {classes.Header}>
            <div className = {classes.Menu}>
                <span className = {['fa fa-bars',classes.MenuIcon].join(' ')}></span>
            </div>
            <div className = {classes.Navbar}>
                {SideNavigationTemplate}
                <ProfileNavigation />
                <div className = {classes.Cogs}>
                    <span className = {cogs}></span>
                </div>
            </div>
        </div> 
    );
}

export default Header;