import React from 'react';
import { NavLink } from 'react-router-dom';

import Aux from '../../../hoc/Aux';
import classes from './SideNavigation.css';

const SideNavigation = (props) => {
    return (
        <Aux>
            <NavLink 
                className = {classes.SideNavigation}
                to = {props.toLink}>
                <span className = {props.icon}></span>
            </NavLink>
        </Aux>
    );
}

export default SideNavigation;