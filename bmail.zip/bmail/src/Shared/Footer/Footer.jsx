import React from 'react';

import classes from './Footer.css'

const Footer = () => {
    return (
        <div className = {classes.Footer}>
            <p className = {classes.Cpy}>Copyright © 2018-2019</p>
            <p className = {classes.Version}></p>
        </div>
            /* <div className = {classes.Fill}></div>
            <p className = {classes.copyTxt}><b className = {classes.cpy}>Copyright © 2018-2019</b><span style = {{
                color: '#72afd2',
                lineHeight: '20px',
                fontWeight: 'bold'
            }}> BMAIL</span></p>
            <p className = {classes.Version}><span style = {{color: '#444',fontWeight: 'bold'}}>Version </span>1.0.0</p>
        </div> */
    );
}

export default Footer;