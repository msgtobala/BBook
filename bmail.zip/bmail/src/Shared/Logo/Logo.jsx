import React from 'react';

import logoImage from '../../assets/Images/BM.ico';
import classes from './Logo.css';

const Logo = () => {
    return (
        <div className = {classes.Logo}>
            <img src = {logoImage} alt = "BMail Logo"/>
        </div>
    );
}

export default Logo;