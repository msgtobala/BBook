import React from 'react';

import classes from './Land-Header.css';
import Logo from '../Logo/Logo';

const LandHeader = () => {
    return (
        <div className = {classes.LandHeader}>
            <div className = {classes.Name}>BMAIL</div>
            <Logo />
        </div>
    );
}

export default LandHeader;