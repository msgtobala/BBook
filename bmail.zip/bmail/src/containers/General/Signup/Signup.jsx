import React, { Component } from 'react';

import classes from './Signup.css';
import Input from '../../../UI/Forms/General-Inputs/Input';
import Aux from '../../../hoc/Aux';


class Signup extends Component {
    state = {
        validForm: false,
        currUser: null,
        currName: null,
        currPwd: null,
        currPhone: null,
        signupForm: {
            name: {
                elementType: 'input',
                elementConfig: {
                    type: 'text',
                    placeholder: 'UserName'
                },
                value: '',
                showSpinner: false,
                spinNow: false,
                validation: {
                    required: true,
                    minLength:4
                },
                valid: false,
                visited: false
            },
            email: {
                elementType: 'input',
                elementConfig: {
                    type: 'email',
                    placeholder: 'ex: Bmail@bmail.com'
                },
                value: '',
                showSpinner: true,
                spinNow: false,
                validation: {
                    required: true
                },
                valid: false,
                visited: false
            },
            password: {
                elementType: 'input',
                elementConfig: {
                    type: 'password',
                    placeholder: 'Password'
                },
                value: '',
                showSpinner: false,
                spinNow: false,
                validation: {
                    required: true,
                    length: 6
                },
                valid: false,
                visited: false
            },
            retypePassword: {
                elementType: 'input',
                elementConfig: {
                    type: 'password',
                    placeholder: 'Retype Password'
                },
                value: '',
                showSpinner: true,
                spinNow: false,
                validation: {
                    required: true
                },
                valid: false,
                visited: false
            },
            phone: {
                elementType: 'input',
                elementConfig: {
                    type: 'text',
                    placeholder: 'Phone Number'
                },
                value: '',
                showSpinner: false,
                spinNow: false,
                validation: {
                    required: true,
                    length: 10
                },
                valid: false,
                visited: false
            },
        },
        accounts: [],
        messages: [
            { 
                name: 'balaji',
                email: 'rslbalaji@bmail.com',
                mails: [],
                sent:  [],
                draft: [],
                trash: []
            }
        ],
        showError: false,
        errorMessage: null
    }

    validityChecker (formEle,element,identifier,rules,value) {
        if(identifier === 'name'){
            if(value.trim() !== '' && value.length >= rules.minLength){
                return true;
            }else{
                return false;
            }
        }else if(identifier === 'email'){
            if(value !== ''){
                let len = this.state.accounts.length;
                if(len === 0){
                    element.spinNow = false;
                    return true;
                }
                for(let itr in this.state.accounts){
                    if(this.state.accounts[itr].email !== value){
                        element.spinNow = false;
                        formEle[identifier] = element;
                        this.setState({showError: false,currUser: value, signupForm: formEle})
                        return true;
                    }else{
                        let spinConfig = {...this.state.signupForm};
                        const spinele = {...spinConfig[identifier]};
                        spinele.spinNow = false;
                        this.setState({showError: true,errorMessage: 'User Already Exists',currUser: value})
                        return false;
                    }
                }
            }
        }
        else if(identifier === 'password'){
                if(value !== '' && value.length >= rules.length){
                    this.setState({currPwd: value,showError: false})
                    return true;
                }else{
                    this.setState({currPwd: null,showError: true, errorMessage: 'Password Must be 6 Characters'})
                    return false;
                }
        }else if(identifier === 'phone'){
             if(value !== '' && value.length >= rules.length){
                    this.setState({currPhone: value})
                    return true;
                }else{
                    return false;
                }
        }else if(identifier === 'retypePassword'){
            let pwd = this.state.currPwd;
                if(value === pwd){
                    element.spinNow = false;
                    formEle[identifier] = element;
                    this.setState({showError:false,signupForm: formEle})
                    return true;
                }else{
                    this.setState({showError: true, errorMessage: 'Password Does Not Match'})
                    return false;
                }
            }
        }
    
    createAccountHandler = () => {
        let messageObj = null;
        let user = null;
        let messagesArray = window.sessionStorage.getItem('messages'); // all messages from session
        messagesArray = JSON.parse(messagesArray);
        let users = window.sessionStorage.getItem('user'); // all user from session
        users = JSON.parse(users);
        if(users !== null && messagesArray !== null){
            user = {
                id: Object.keys(users).length + 1,
                name: this.state.signupForm.name.value,
                email: this.state.signupForm.email.value,
                phone: this.state.currPhone,
                password: this.state.currPwd
            }
            messageObj =  { 
                id: Object.keys(users).length + 1,
                name: this.state.signupForm.name.value,
                email: this.state.signupForm.email.value,
                mails: [],
                sent:  [],
                draft: [],
                trash: []
            }
            users.push(user);
            messagesArray.push(messageObj);
            sessionStorage.setItem('messages',JSON.stringify(messagesArray))
            sessionStorage.setItem('user', JSON.stringify(users));
            this.props.history.push({pathname: '/signin'})   
        }else if(users === null && messagesArray === null){
            user = {
                id: 1,
                name: this.state.signupForm.name.value,
                email: this.state.signupForm.email.value,
                phone: this.state.currPhone,
                password: this.state.currPwd
            }
            messageObj =  { 
                id:  1,
                name: this.state.signupForm.name.value,
                email: this.state.signupForm.email.value,
                mails: [],
                sent:  [],
                draft: [],
                trash: []
            }
            let currMails = []; 
            let currAcc = [];
            currAcc.push(user);
            currMails.push(messageObj);
            sessionStorage.setItem('messages',JSON.stringify(currMails));
            sessionStorage.setItem('user', JSON.stringify(currAcc));
            this.props.history.push({pathname: '/signin'})   
        }
    }

    inputChangedHandler = (event,identifier) => {
        let updatedsignupForm = {...this.state.signupForm};
        const updatedsignupFormElement = {...updatedsignupForm[identifier]};
        updatedsignupFormElement.value = event.target.value;
        updatedsignupFormElement.spinNow = true;
        let validity = this.validityChecker(updatedsignupForm,updatedsignupFormElement,identifier, updatedsignupFormElement.validation,event.target.value);
        updatedsignupFormElement.valid = validity;
        updatedsignupFormElement.visited = true;
        updatedsignupForm[identifier] = updatedsignupFormElement;
        let formIsValid = false;
        for(let itr in updatedsignupForm){
            if(updatedsignupForm[itr].valid === true){
                formIsValid = true;
            }else{
                formIsValid = false;
                break;
            }
        }
        this.setState({signupForm: updatedsignupForm, validForm: formIsValid})
    }
    render () {
        const formElementArray = [];
        for(let itr in this.state.signupForm){
            formElementArray.push({
                id: itr,
                config: this.state.signupForm[itr]
            });
        }
        let form = (
            <div className = {classes.Form}>
                {
                    formElementArray.map(ele=>(
                      <Aux key = {ele.id}>
                        <Input 
                            elementConfig = {ele.config.elementConfig}
                            elementType = {ele.config.elementType}
                            value = {ele.config.value}
                            showSpinner = {ele.config.showSpinner}
                            spin = {ele.config.spinNow}
                            valid = {!ele.config.valid}
                            visited = {ele.config.visited}
                            changed = {(event) => this.inputChangedHandler(event,ele.id) }/>
                      </Aux>
                     ))
                }
            </div>
        );

        let errorMessage = 'ERR';
        if(this.state.showError){
            errorMessage = this.state.errorMessage;
        }
        return (
            <div className = {classes.Signup}>
                <h4>Enter Your Contact Data</h4>
                <p  style = {{ visibility: errorMessage === 'ERR' ? 'hidden':'visible',
                              color: 'red',
                              padding: '2%'}}>{errorMessage}</p>
                {form}
                <button 
                    className = {classes.Button}
                    disabled = {!this.state.validForm}
                    onClick = {this.createAccountHandler} >CREATE ACCOUNT</button>
            </div>
        );
    }
}

export default Signup;