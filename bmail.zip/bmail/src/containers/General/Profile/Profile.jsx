import React, { Component } from 'react';

class Profile extends Component {
    render (){
        return (
            <p>Profile Page</p>
        );
    }
}

export default Profile;