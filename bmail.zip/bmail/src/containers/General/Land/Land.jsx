import React, { Component } from 'react';
import { Link } from 'react-router-dom';

import classes from './Land.css';
import Aux from '../../../hoc/Aux';

class Land extends Component {
    render () {
        return (
            <Aux className = {classes.Land}>
                <div className = {classes.Landing}>
                    <h3 className = {classes.BmailHeading}>BMail App</h3>
                    <p className = {classes.BmailDesc}><span className = {classes.BmailSpan}>BMAIL</span> is a Dynamic Mailbox that allows us to Send Mails and Manage them</p>
                    <p className = {classes.BmailDesc}>Login to use BMail for Free</p>
                </div>
               <div className = {classes.Links}>
                  <Link className = {classes.Link} 
                        to = {{ 
                          pathname: "/signin",
                          hash: '#signin'
                        }}>Signin</Link>
                   <Link className = {classes.Link} 
                         to = {{
                             pathname: "/signup",
                             hash: '#signup'
                         }}>Signup</Link>
               </div>
            </Aux>
        );
    }
}

export default Land;