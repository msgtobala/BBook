import React, { Component } from 'react';
import { Link } from 'react-router-dom';


import classes from './Signin.css';
import Aux from '../../../hoc/Aux';
import Input from '../../../UI/Forms/Advanced-Inputs/Input';

class Signin extends Component {

   state = {
        accounts: null,
        validAccount: false,
        valid: null,
        validUser: false,
        validForm: false,
        validpwd: null,
        error: false,
        errorMessage: null,
        authId: null,
        siginForm: {
            bmail: {
                elementType: 'input',
                elementConfig: {
                    type: 'email',
                    placeholder: 'ex: user@bmail.com'
                },
                value: '',
                valid: false,
                validation: {
                    required: true
                }
            },
            password: {
                elementType: 'input',
                elementConfig: {
                    type: 'password',
                    placeholder: 'BMail Password'
                },
                value: '',
                valid: false,
                validation: {
                    required: true,
                    minLength: 6
                }
            }
        }  
   }
    
    componentDidMount() {
         let users = window.sessionStorage.getItem('user');
         let messages = window.sessionStorage.getItem('messages')
         messages = JSON.parse(messages);
         users = JSON.parse(users);
         this.setState({accounts: users}, ()=> {
            console.log(this.state.accounts);   // all accounts
            console.log(messages);              // all messages
        });
    }
    checkValidity (value,element, rules) {
        this.setState({error: false})
        if(element === 'bmail'){
            let users = this.state.accounts;
            for(let itr in users){
                if(users[itr].email === value){
                    this.setState({validpwd: users[itr].password,validUser: true,authId: users[itr].id});
                    return true;
                }else{
                    this.setState({validAccount:false, validUser: false})
                }
            }
            return false;
        }else if(element === 'password' ){
            if(this.state.validUser){
                if(this.state.validpwd === value){
                    window.sessionStorage.setItem('authUsr',true);
                    this.setState({validAccount: true,error: false,errorMessage: null})
                    return true;
                }else{
                    window.sessionStorage.setItem('authUsr',false);
                    this.setState({validAccount: false, error: true, errorMessage: 'Incorrect Password'})
                }
            }else if(this.state.validUser === false){
                this.setState({error: true, errorMessage: 'User Does Not Exists'})
                return false;
            }
        }
    }

    inputChangedHandler = (event, identifier) => {
        let updatedSigninForm = {...this.state.siginForm };
        let updatedSigninFormElement = { ...updatedSigninForm[identifier] };
        updatedSigninFormElement.value = event.target.value;
        updatedSigninForm[identifier] = updatedSigninFormElement;
        let validity = this.checkValidity(event.target.value,identifier,updatedSigninFormElement.validation);
        updatedSigninFormElement.valid = validity;
        let formIsValid = false;
        for(let itr in updatedSigninForm){
            if(updatedSigninForm[itr].valid === true){
                formIsValid = true;
            }else{
                formIsValid = false;
                break;
            }
        }
        this.setState({siginForm: updatedSigninForm, validForm: formIsValid})
    }

    loginHandler = () => {
        let queryParams = [];
        queryParams.push(encodeURIComponent('authUser') + '=' + encodeURIComponent(true));
        queryParams.push(encodeURIComponent('authId') + '=' + encodeURIComponent(this.state.authId));
        let searchParams = queryParams.join('&');
        if(this.state.validAccount){
            this.props.history.replace({
                pathname:'/dashboard',
                search: '?' + searchParams
            })
        }
    }

    render () {
        const formElementArray = [];
        for(let itr in this.state.siginForm){
            formElementArray.push({
                id: itr,
                config: this.state.siginForm[itr]
            });
        }

        let formTemplate = (
            <div>
                {
                    formElementArray.map(ele=> (
                        <Aux key = {ele.id}>
                            <Input 
                                  elementConfig = {ele.config.elementConfig}
                                  elementType = {ele.config.elementType}
                                  value = {ele.config.value}
                                  valid = {ele.config.valid}
                                  changed = {(event) => this.inputChangedHandler(event, ele.id)} />
                        </Aux>
                    ))
                }
            </div>
        );

         
        let errorMessage = 'ERR';
        if(this.state.error){
            errorMessage  = this.state.errorMessage;
        }
        return (
          <Aux>
            <div className = {classes.Signin}>
                <p>Login to use <span className = {classes.Bmail}>BMAIL</span></p>
                <p  style = {{ visibility: errorMessage === 'ERR' ? 'hidden':'visible',
                              color: '#191970',
                              padding: '3%'}}>{errorMessage}</p>
                {formTemplate}
                <button 
                        className = {classes.Button}
                        disabled = {!this.state.validForm && !this.state.validAccount} 
                        onClick = {this.loginHandler}>LOGIN</button>
            </div>
            <div className = {classes.Links}>
              <Link
                 className = {classes.Link} 
                 to = {{
                   pathname: "/",
                   hash: '#home',
              }}>HOME</Link>
              <Link 
                className = {classes.Link}
                 to = {{
                 pathname: "/signup",
                 hash: '#signup'
               }}>SIGN UP</Link>
            </div>
          </Aux>
        );
    }
}

export default Signin;