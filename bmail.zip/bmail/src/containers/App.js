import React, { Component } from 'react';
import { Route, Switch } from 'react-router-dom';

import Aux from '../hoc/Aux';
import Layout from '../components/Layout/Layout';
import Signin from '../containers/General/Signin/Signin';
import Signup from '../containers/General/Signup/Signup';
import Dashboard from '../containers/Mailbox/Dashboard/Dashboard';
import Land from '../containers/General/Land/Land';


class App extends Component {
  render() {
    return (
      <Aux>
          <Switch>
              <Route path = "/dashboard" component = {Dashboard} />
              <Layout>
                  <Route path = "/signin" component = {Signin} />
                  <Route path = "/signup" component = {Signup} />
                  <Route exact path = "/" component = {Land}/>
              </Layout>
          </Switch>
      </Aux>
    );
  }
}

export default App;
