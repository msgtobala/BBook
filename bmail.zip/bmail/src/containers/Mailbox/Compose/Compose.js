import React, { Component } from 'react';
import {withRouter} from 'react-router-dom';

import classes from './Compose.css';
import FolderElement from '../../../components/Mailbox/Inbox/FolderElements/FolderElement';
import CatagoryElement from '../../../components/Mailbox/Inbox/CatagoryElements/CatagoryElements';
import Inputs from '../../../UI/Forms/Inputs/Inputs';


class Compose extends Component {
    state = {
        folders: [
            {name: 'Inbox', icon: 'fa fa-inbox', to: '/dashboard/inbox'},
            {name: 'Sent', icon: 'fa fa-envelope-o',to: '/dashboard/outbox'},
            {name: 'Draft', icon:'fa fa-file-text-o',to: '/dashboard/draft'},
            {name: 'Trash',icon: 'fa fa-trash-o',to: '/dashboard/trash'}
        ],
        catagories : [
            {name: 'Important',icon: 'fa fa-circle-o',to: '/dashboard/important',color:'#dd4b39'},
            {name: 'Pinned',icon: 'fa fa-circle-o',to: '/dashboard/pinned',color: '#f39c12 '},
            {name: 'Starred',icon: 'fa fa-circle-o',to: '/dashboard/starred',color: '#3c8dbc'}
        ],
        messages: [
            {id: '1',icon: 'fa fa-star-o',from: 'Balaji Venkatraman',subject:'Greetings',body: 'Hai hello feel free to use Bmail',to:'/'},
            {id: '2',icon: 'fa fa-star-o',from: 'Balaji',subject:'Greetings From Bmail Team',body:'Hai hello feel free to use Bmail.It is absolutely free and you can use it where ever you are',to:'/'},
            {id: '3',icon: 'fa fa-star-o',from: 'Bala',subject:'Greetings',body: 'Hai',to:'/'}
        ],
        composeForm: {
            to: {
                elementType: 'input',
                elementConfig: {
                    type: 'email',
                    placeholder: 'To:'
                },
                value: '',
                valid: false,
                visited: false,
                validation: {
                    required: true,
                }
            },
            subject: {
                elementType: 'input',
                elementConfig: {
                    type: 'text',
                    placeholder: 'Subject: (max: 20 characters)'
                },
                value: '',
                valid: false,
                visited: false,
                validation: {
                    required: true,
                    maxLength: 20
                }
            },
            body: {
                elementType: 'textarea',
                elementConfig: {
                    placeholder: 'Body goes here'
                },
                value: '',
                valid: false,
                visited: false,
                validation: {
                    required: true,
                }
            }
        },
        accounts: null,
        error: false,
        errorMessage: null,
        validForm: false,
        currEmail: null,
        currSubject: null,
        currBody: null
    }

    componentWillMount() {
        let allUsers = window.sessionStorage.getItem('user');
        allUsers = JSON.parse(allUsers);
        this.setState({accounts: allUsers});
    }

    ComposeMailHandler = () => {
        this.props.history.push({
            pathname: '/dashboard/inbox',
            search: '#inbox'
        })
    }

    validityChecker(identifier,value,rules) {
       if(identifier === 'to'){
            if(value !== ''){
                let mails = this.state.accounts;
                for(let itr in mails){
                    if(mails[itr].email === value){
                        this.setState({currEmail:value,error: false,errorMessage: null})
                        return true;
                    }else if (mails[itr].email !== value){
                        this.setState({currEmail: value,error: true,errorMessage: 'User Not Exists'});
                    }
                }
                return false;
            }else{
                return false;
            }
       }else if(identifier === 'subject'){
            if(value !== ''){
                if(value.length <= rules.maxLength){
                    this.setState({currSubject: value,error: false,errorMessage: null});
                    return true;
                }else{
                    this.setState({error: true,errorMessage: 'Subject: Length 20 characters'});
                    return false;
                }
            }
       }else if (identifier === 'body') {
            if(value !== ''){
                this.setState({currBody: value,error: false,errorMessage: null});
                return true; 
            }else{
                this.setState({error: false,errorMessage: null});
                return false;
            }
       }
    }

    inputChangedHandler = (event,identifier) => {
        let updatedComposeForm = this.state.composeForm;
        let updatedComposeFormElement = updatedComposeForm[identifier];
        updatedComposeFormElement.value = event.target.value;
        updatedComposeForm[identifier] = updatedComposeFormElement;
        let validity = this.validityChecker(identifier,event.target.value,updatedComposeForm[identifier].validation);
        updatedComposeFormElement.valid = validity;
        let formIsValid = false;
        for(let itr in updatedComposeForm){
            if(updatedComposeForm[itr].valid === true){
                formIsValid = true;
            }else{
                formIsValid = false;
                break;
            }
        }
        this.setState({composeForm: updatedComposeForm, validForm: formIsValid})
    }

    discardMailHandler = () => {
        document.getElementById('to').value = "";
        document.getElementById('subject').value = "";
        document.getElementById('body').value = "";
    }



    render () {
        let folderTemplate = (
            this.state.folders.map(ele => (
                <FolderElement 
                            key = {ele.name}
                            icon = {ele.icon}
                            name = {ele.name}
                            toLink = {ele.to}/>
            ))
        );
        
        let catagoryTemplate = (
            this.state.catagories.map(ele=>(
                <CatagoryElement 
                            key = {ele.name}
                            icon = {ele.icon}
                            name = {ele.name}
                            toLink = {ele.to}
                            color = {ele.color}/>
            ))
        );
        
        let formArray = [];
        for(let itr in this.state.composeForm){
            formArray.push({
                id: itr,
                config: this.state.composeForm[itr]
            })
        }

        let formElementTemplate = (
            formArray.map(form => (
                <Inputs
                      id = {form.id}
                      key = {form.id}
                      elementType = {form.config.elementType}
                      elementConfig = {form.config.elementConfig}
                      value = {form.config.value}
                      changed = {(event) => this.inputChangedHandler(event,form.id) }/>
            ))
        );
        let errorMessage = 'ERR';
        if(this.state.error){
            errorMessage = this.state.errorMessage;
        }
        return (
            <div className = {classes.ComposeMessages}>
                <div className = {classes.Panel}>
                    <p className = {classes.Dashboard}>Compose</p>
                </div>
                <div className = {classes.Pagination}>
                  <span
                      style = {{fontSize: '12px',
                                margin: '0px 8px'
                              }} 
                      className = {"fa fa-dashboard"}></span>
                  <span className = {classes.Crumbs}><span className = {classes.Home}>Dashboard</span> > Compose Mail</span>
                </div>
                <div className = {classes.ComposeContents}>
                    <div className = {classes.Folders}>
                        <button className = {classes.Compose}
                                onClick = {this.ComposeMailHandler}>Back To Inbox</button>
                        <div className = {classes.FolderBox}>
                            <p className = {classes.FolderTitle}>Folders
                                <span className = {['fa fa-plus',classes.Expand].join(' ')}></span>
                            </p>
                            {folderTemplate}
                        </div>
                        <div className = {classes.FolderBox}>
                            <p className = {classes.FolderTitle}>Catagories
                                <span className = {['fa fa-plus',classes.Expand].join(' ')}></span>
                            </p>
                            {catagoryTemplate}
                        </div>
                    </div>
                    <div className = {classes.ComposeSection}>
                         <div className = {classes.TrashHeading}>
                            <p className = {classes.TrashHead}>Compose New Message</p>
                        </div>
                       <div className = {classes.ComposeFormElements}>
                            <p  style = {{ visibility: errorMessage === 'ERR' ? 'hidden':'visible',
                              color: 'red',
                              padding: '1%'}}>{errorMessage}</p>
                           {formElementTemplate}
                           <div className = {classes.pullLeft}>
                               <button className = {classes.controlButtons}
                                       onClick = {this.discardMailHandler}>
                                    <span className = {['fa fa-close',classes.faControls].join(' ')}></span>Discard 
                               </button>
                           </div>
                           <div className = {classes.pullRight}>
                               <button className = {classes.controlButtons}
                                       onClick = {()=>this.props.draftMail(this.state.currEmail,this.state.currSubject,this.state.currBody)}>
                                    <span className = {['fa fa-pencil',classes.faControls].join(' ')}></span>Draft 
                               </button>
                               <button 
                                      disabled = {!this.state.validForm}
                                      className = {classes.SendButton}
                                      onClick = {()=>this.props.sendMail(this.state.currEmail,this.state.currSubject,this.state.currBody)}>
                                    <span className = {['fa fa-envelope-o',classes.faControls].join(' ')}></span>Send 
                               </button>
                           </div>
                       </div>
                    </div>
                </div>
            </div>
        );
    }
}

export default withRouter(Compose);