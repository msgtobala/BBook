import React , { Component } from 'react';
import { withRouter } from 'react-router';

import classes from './ReadMessages.css';
import FolderElement from '../../../components/Mailbox/Inbox/FolderElements/FolderElement';
import CatagoryElement from '../../../components/Mailbox/Inbox/CatagoryElements/CatagoryElements';

class ReadMessages extends Component {
    state = {
        folders: [
            {name: 'Inbox', icon: 'fa fa-inbox', to: '/dashboard/inbox'},
            {name: 'Sent', icon: 'fa fa-envelope-o',to: '/dashboard/outbox'},
            {name: 'Draft', icon:'fa fa-file-text-o',to: '/dashboard/draft'},
            {name: 'Trash',icon: 'fa fa-trash-o',to: '/dashboard/trash'}
        ],
        catagories : [
            {name: 'Important',icon: 'fa fa-circle-o',to: '/dashboard/important',color:'#dd4b39'},
            {name: 'Pinned',icon: 'fa fa-circle-o',to: '/dashboard/pinned',color: '#f39c12 '},
            {name: 'Starred',icon: 'fa fa-circle-o',to: '/dashboard/starred',color: '#3c8dbc'}
        ],
        messages: [],
        currMessage: null,
        important: 'fa fa-info-circle',
        starred: 'fa fa-star-o',
        pinned: 'fa fa-map-pin',
        locked: 'fa fa-lock'
    }

    componentDidMount() {
        let thisUser = this.props.authId;
        let allMessages = window.sessionStorage.getItem('messages');
        allMessages = JSON.parse(allMessages);
        let tempMails = null; 
        for(let itrId in allMessages){
            if(allMessages[itrId].id === +thisUser){
                tempMails = allMessages[itrId].mails;
            }
        }
        let query = new URLSearchParams(this.props.location.search);
        let currMessages = null;
        let mailId = null;
        for(let param of query.entries()){
            mailId = param[1];
        }
        for(let itrId in tempMails){
            if(tempMails[itrId].id === +mailId){
                currMessages = tempMails[itrId]
            }
        }
        this.setState({currMessage:currMessages},()=>{
            console.log(this.state.currMessage.email)
        })
    }
    render () {
        let folderTemplate = (
            this.state.folders.map(ele => (
                <FolderElement 
                            key = {ele.name}
                            icon = {ele.icon}
                            name = {ele.name}
                            toLink = {ele.to}/>
            ))
        );
        
        let catagoryTemplate = (
            this.state.catagories.map(ele=>(
                <CatagoryElement 
                            key = {ele.name}
                            icon = {ele.icon}
                            name = {ele.name}
                            toLink = {ele.to}
                            color = {ele.color}/>
            ))
        );
        let MessageTemplate = <p>Loading</p>;
        if(this.state.currMessage){
            MessageTemplate = (
                <div className = {classes.MessageSection}>
                        <div className = {classes.InboxHeading}>
                            <p className = {classes.InboxHead}>Read Mail</p>
                        </div>
                        <div className = {classes.SubjectSection}>
                            <p className = {classes.Sub}>Subject: {this.state.currMessage.subject}</p>
                            <p className = {classes.From}>From: {this.state.currMessage.email} {this.state.messages.from}<span className = {classes.Date}>{this.state.currMessage.date}</span></p>
                        </div>
                        <div className = {classes.Controls}>
                            <div>
                                <span className = {['fa fa-trash',classes.ControlIcons].join(' ')}></span>
                                <span className = {['fa fa-mail-reply',classes.ControlIcons].join(' ')}></span>
                                <span className = {['fa fa-mail-forward',classes.ControlIcons].join(' ')}></span>
                            </div>
                            <div>
                                <span className = {[this.state.starred,classes.Star].join(' ')}
                                      style = {{color: this.state.currMessage.starred?'#3c8dbc':'black'}}></span>
                                <span className = {[this.state.pinned,classes.Pin].join(' ')}
                                      style = {{color: this.state.currMessage.pinned?'#3c8dbc':'black'}}></span>
                                <span className = {[this.state.important,classes.Important].join(' ')}
                                      style = {{color: this.state.currMessage.important?'#3c8dbc':'black'}}></span>
                            </div>
                        </div>
                        <div className = {classes.MessageBody}>
                              {this.state.currMessage.body}
                        </div>
                        <div className = {classes.ButtonControls}>
                            <button className = {classes.ButtonControl}>
                                <span className = {['fa fa-trash',classes.ControlIco].join(' ')}></span> Trash
                            </button>
                            <button className = {classes.ButtonControl}>
                                <span className = {['fa fa-mail-reply',classes.ControlIco].join(' ')}></span> Reply
                            </button>
                            <button className = {classes.ButtonControl}>
                                <span className = {['fa fa-mail-forward',classes.ControlIco].join(' ')}></span> Forward
                            </button>
                        </div>
                    </div> 
            );
        }
        return (
            <div className = {classes.ReadMessages}>
                <div className = {classes.Panel}>
                    <p className = {classes.Dashboard}>Read Messages</p>
                </div>
                <div className = {classes.Pagination}>
                  <span
                      style = {{fontSize: '12px',
                                margin: '0px 8px'
                              }} 
                      className = {"fa fa-dashboard"}></span>
                  <span className = {classes.Crumbs}><span className = {classes.Home}>Inbox</span> > Read Messages</span>
                </div>
                <div className = {classes.MessageContents}>
                    <div className = {classes.Folders}>
                        <button className = {classes.Compose}>Compose</button>
                        <div className = {classes.FolderBox}>
                            <p className = {classes.FolderTitle}>Folders
                                <span className = {['fa fa-plus',classes.Expand].join(' ')}></span>
                            </p>
                            {folderTemplate}
                        </div>
                        <div className = {classes.FolderBox}>
                            <p className = {classes.FolderTitle}>Catagories
                                <span className = {['fa fa-plus',classes.Expand].join(' ')}></span>
                            </p>
                            {catagoryTemplate}
                        </div>
                    </div>
                    {MessageTemplate} 
                </div>
            </div>
        );
    }
}

export default withRouter(ReadMessages);