import React, { Component } from 'react';
import { withRouter } from 'react-router';


import classes from './Inbox.css';
import FolderElement from '../../../components/Mailbox/Inbox/FolderElements/FolderElement';
import CatagoryElement from '../../../components/Mailbox/Inbox/CatagoryElements/CatagoryElements';
import MessageElement from '../../../components/Mailbox/Inbox/MessageElement/MessageElement';

class Inbox extends Component {
    state = {
        folders: [
            {name: 'Inbox', icon: 'fa fa-inbox', to: '/dashboard/inbox'},
            {name: 'Sent', icon: 'fa fa-envelope-o',to: '/dashboard/outbox'},
            {name: 'Draft', icon:'fa fa-file-text-o',to: '/dashboard/draft'},
            {name: 'Trash',icon: 'fa fa-trash-o',to: '/dashboard/trash'}
        ],
        catagories : [
            {name: 'Important',icon: 'fa fa-circle-o',to: '/dashboard/important',color:'#dd4b39'},
            {name: 'Pinned',icon: 'fa fa-circle-o',to: '/dashboard/pinned',color: '#f39c12 '},
            {name: 'Starred',icon: 'fa fa-circle-o',to: '/dashboard/starred',color: '#3c8dbc'}
        ],
        messages: [],
        currUser: null,
        allUsers: null,
        delIcon: false
    }

    componentDidMount () {
        let thisUser = this.props.authId;
        let allUsers = window.sessionStorage.getItem('user');
        allUsers = JSON.parse(allUsers);
        let allMessages = window.sessionStorage.getItem('messages');
        allMessages = JSON.parse(allMessages);
        let tempMails = null;
        console.log(allMessages);
        for(let itrId in allMessages){
            if(allMessages[itrId].id === +thisUser){
                tempMails = allMessages[itrId].mails;
            }
        }
        this.setState({allUsers: allUsers, messages: tempMails});
    }

    mailClickedHandler = (id) => {
        const queryParams = [];
        queryParams.push(encodeURIComponent('mailId') + '=' + encodeURIComponent(id));
        console.log(id);
        this.props.history.push({
            pathname: '/dashboard/inbox/readmessages',
            search: '?' + queryParams
        });
    }

    starClickedHandler = (id) => {
        let starValue = this.state.messages;
        let thisUser = this.props.authId;
        let allMessages = window.sessionStorage.getItem('messages');
        allMessages = JSON.parse(allMessages);
        let tempmailId = null;
        for(let itrId in allMessages){
            if(allMessages[itrId].id === +thisUser){
                tempmailId = itrId;
            }
        }
        console.log(tempmailId);
        for(let itr in starValue){
            if(starValue[itr].id === id){
                if(starValue[itr].icon === 'fa fa-star-o' ){
                    starValue[itr].icon = 'fa fa-star';
                    starValue[itr].important = true;
                }else{
                    starValue[itr].icon = 'fa fa-star-o';
                    starValue[itr].important = false;
                }
            }
        }
        allMessages[tempmailId].mails = starValue;
        sessionStorage.setItem('messages',JSON.stringify(allMessages));
        this.setState({messages: starValue});
    }

    ComposeMailHandler = () => {
        this.props.history.push({
            pathname: '/dashboard/compose',
            hash: '#compose'
        })
    }

    handleMouseHover = () => {
        let updatedDel = !this.state.delIcon;
        this.setState({delIcon: updatedDel})
    }

    deleteMailHandler = (id) => {
        let thisUser = this.props.authId;
        let allMessages = window.sessionStorage.getItem('messages');
        allMessages = JSON.parse(allMessages);
        let tempMails = null;
        let tempitrId = null;
        for(let itrId in allMessages){
            if(allMessages[itrId].id === +thisUser){
                tempMails = allMessages[itrId].mails;
                tempitrId =itrId;
            }
        }
        for(let itrId in tempMails){
            if(tempMails[itrId].id === id){
                id = itrId;
            }
        }
        tempMails.splice(id, 1);
        allMessages[tempitrId].mails = tempMails;
        sessionStorage.setItem('messages',JSON.stringify(allMessages));
        this.setState({messages:allMessages});
    }

    render () {
        let folderTemplate = (
            this.state.folders.map(ele => (
                <FolderElement 
                            key = {ele.name}
                            icon = {ele.icon}
                            name = {ele.name}
                            toLink = {ele.to}/>
            ))
        );
        
        let catagoryTemplate = (
            this.state.catagories.map(ele=>(
                <CatagoryElement 
                            key = {ele.name}
                            icon = {ele.icon}
                            name = {ele.name}
                            toLink = {ele.to}
                            color = {ele.color}/>
            ))
        );

        let inboxTemplate = <p style = {{margin: 'auto',textAlign: 'center'}}>No Mails Here</p>;
        if(this.state.messages && this.state.messages.length && this.state.messages.length !== 0){
            inboxTemplate = (
                this.state.messages.map(ele=>(
                    <MessageElement 
                                key = {ele.id}
                                from = {ele.email}
                                date = {ele.date}
                                important = {ele.important}
                                starred = {ele.starred}
                                locked = {ele.locked}
                                pinned = {ele.locked}
                                subject = {ele.subject}
                                body = {ele.body}
                                icon = {ele.icon}
                                displayDel = {true}
                                deleteMail = {()=>this.deleteMailHandler(ele.id)}
                                // enter = {this.handleMouseHover}
                                // leave = {this.handleMouseHover}
                                mailClicked = {(id)=> this.mailClickedHandler(ele.id)}
                                starClicked = {(id)=> this.starClickedHandler(ele.id)}/>
                ))
            );
        }else {
            inboxTemplate = <p style = {{margin: 'auto',textAlign: 'center'}}>No Mails Here</p>; 
        }
        return (
            <div className = {classes.Inbox}>
                <div className = {classes.Panel}>
                    <p className = {classes.Dashboard}>MailBox<span className = {classes.ControlPanel}> 12 New Messages</span></p>
                </div>
                <div className = {classes.Pagination}>
                  <span
                      style = {{fontSize: '12px',
                                margin: '0px 8px'
                              }} 
                      className = {"fa fa-dashboard"}></span>
                  <span className = {classes.Crumbs}><span className = {classes.Home}>Dashboard</span> > Inbox</span>
                </div>
                <div className = {classes.InboxContents}>
                    <div className = {classes.Folders}>
                        <button className = {classes.Compose} 
                                onClick = {this.ComposeMailHandler}>Compose</button>
                        <div className = {classes.FolderBox}>
                            <p className = {classes.FolderTitle}>Folders
                                <span className = {['fa fa-plus',classes.Expand].join(' ')}></span>
                            </p>
                            {folderTemplate}
                        </div>
                        <div className = {classes.FolderBox}>
                            <p className = {classes.FolderTitle}>Catagories
                                <span className = {['fa fa-plus',classes.Expand].join(' ')}></span>
                            </p>
                            {catagoryTemplate}
                        </div>
                    </div>
                    <div className = {classes.InboxSection}>
                        <div className = {classes.InboxHeading}>
                            <p className = {classes.InboxHead}>Inbox</p>
                            <div className = {classes.SearchBox}>
                                <input className = {classes.Search} type = "text" placeholder = "Search Mail"/>
                                <span className = {['fa fa-search',classes.SearchIcon].join(' ')}></span>
                            </div>
                        </div>
                        <div className = {classes.OptionButtons}>
                            <span className = {classes.Checkbox}>
                                <input className = {classes.Box} type = "checkbox"/>
                            </span>&nbsp;
                            <span className = {["fa fa-trash-o", classes.TrashButton].join(' ')}></span>
                            <div className = {classes.Paginate}>
                                <span className = {classes.Numbers}>1-10/100</span>&nbsp;
                                <span className = {['fa fa-angle-left',classes.Arrows].join(' ')}></span>&nbsp;
                                <span className = {['fa fa-angle-right',classes.Arrows].join(' ')}></span>
                            </div>
                        </div>
                        {inboxTemplate}
                    </div>
                </div>
            </div>
        );
    }
}

export default withRouter(Inbox);