import React, { Component } from 'react';
import { withRouter } from 'react-router';

import classes from './Outbox.css';
import FolderElement from '../../../components/Mailbox/Inbox/FolderElements/FolderElement';
import CatagoryElement from '../../../components/Mailbox/Inbox/CatagoryElements/CatagoryElements';
import MessageElement from '../../../components/Mailbox/Inbox/MessageElement/MessageElement';

class Outbox extends Component {
    state = {
        folders: [
            {name: 'Inbox', icon: 'fa fa-inbox', to: '/dashboard/inbox'},
            {name: 'Sent', icon: 'fa fa-envelope-o',to: '/dashboard/outbox'},
            {name: 'Draft', icon:'fa fa-file-text-o',to: '/dashboard/draft'},
            {name: 'Trash',icon: 'fa fa-trash-o',to: '/dashboard/trash'}
        ],
        catagories : [
            {name: 'Important',icon: 'fa fa-circle-o',to: '/dashboard/important',color:'#dd4b39'},
            {name: 'Pinned',icon: 'fa fa-circle-o',to: '/dashboard/pinned',color: '#f39c12 '},
            {name: 'Starred',icon: 'fa fa-circle-o',to: '/dashboard/starred',color: '#3c8dbc'}
        ],
        messages: [
            {id: '1',icon: 'fa fa-star-o',from: 'Balaji Venkatraman',subject:'Greetings',body: 'Hai hello feel free to use Bmail',to:'/'},
            {id: '2',icon: 'fa fa-star-o',from: 'Balaji',subject:'Greetings From Bmail Team',body:'Hai hello feel free to use Bmail.It is absolutely free and you can use it where ever you are',to:'/'},
            {id: '3',icon: 'fa fa-star-o',from: 'Bala',subject:'Greetings',body: 'Hai',to:'/'}
        ]
    }

    componentDidMount () {
        let thisUser = this.props.authId;
        let allUsers = window.sessionStorage.getItem('user');
        allUsers = JSON.parse(allUsers);
        let allMessages = window.sessionStorage.getItem('messages');
        allMessages = JSON.parse(allMessages);
        let tempMails = null;
        for(let itrId in allMessages){
            if(allMessages[itrId].id === +thisUser){
                tempMails = allMessages[itrId].sent;
            }
        }
        this.setState({allUsers: allUsers, messages: tempMails});
    }


    mailClickedHandler = (id) => {
        const queryParams = [];
        queryParams.push(encodeURIComponent('mailId') + '=' + encodeURIComponent(id));
        this.props.history.push({
            pathname: '/dashboard/outbox/readmessages',
            search: '?' + queryParams
        });
    }

    starClickedHandler = (id) => {
        let starValue = this.state.messages;
        for(let itr in starValue){
            if(starValue[itr].id === id){
                if(starValue[itr].icon === 'fa fa-star-o' ){
                    starValue[itr].icon = 'fa fa-star';
                }else{
                    starValue[itr].icon = 'fa fa-star-o';
                }
            }
        }
        this.setState({messages: starValue});
    }
    
    ComposeMailHandler = () => {
        this.props.history.push({
            pathname: '/dashboard/compose'
        })
    }
    
    render () {
        let folderTemplate = (
            this.state.folders.map(ele => (
                <FolderElement 
                            key = {ele.name}
                            icon = {ele.icon}
                            name = {ele.name}
                            toLink = {ele.to}/>
            ))
        );
        
        let catagoryTemplate = (
            this.state.catagories.map(ele=>(
                <CatagoryElement 
                            key = {ele.name}
                            icon = {ele.icon}
                            name = {ele.name}
                            toLink = {ele.to}
                            color = {ele.color}/>
            ))
        );
        let OutboxTemplate = <p style = {{margin: 'auto',textAlign: 'center'}}>No Mails Here</p>;
        if(this.state.messages && this.state.messages.length){
            OutboxTemplate = (
                this.state.messages.map(ele=>(
                    <MessageElement 
                                key = {ele.id}
                                from = {ele.email}
                                subject = {ele.subject}
                                body = {ele.body}
                                toLink = {ele.to}
                                icon = {ele.icon}
                                mailClicked = {(id)=> this.mailClickedHandler(ele.id)}
                                starClicked = {(id)=> this.starClickedHandler(ele.id)}/>
                ))
            );
        }else{
            OutboxTemplate = <p style = {{margin: 'auto',textAlign: 'center'}}>No Mails Here</p>;   
        }
        return (
            <div className = {classes.Outbox}>
                <div className = {classes.Panel}>
                    <p className = {classes.Dashboard}>Outbox</p>
                </div>
                <div className = {classes.Pagination}>
                  <span
                      style = {{fontSize: '12px',
                                margin: '0px 8px'
                              }} 
                      className = {"fa fa-dashboard"}></span>
                  <span className = {classes.Crumbs}><span className = {classes.Home}>Dashboard</span> > Outbox</span>
                </div>
                <div className = {classes.OutboxContents}>
                <div className = {classes.Folders}>
                        <button className = {classes.Compose}
                                onClick = {this.ComposeMailHandler}>Compose</button>
                        <div className = {classes.FolderBox}>
                            <p className = {classes.FolderTitle}>Folders
                                <span className = {['fa fa-plus',classes.Expand].join(' ')}></span>
                            </p>
                            {folderTemplate}
                        </div>
                        <div className = {classes.FolderBox}>
                            <p className = {classes.FolderTitle}>Catagories
                                <span className = {['fa fa-plus',classes.Expand].join(' ')}></span>
                            </p>
                            {catagoryTemplate}
                        </div>
                    </div>
                    <div className = {classes.OutboxSection}>
                        <div className = {classes.OutboxHeading}>
                            <p className = {classes.OutboxHead}>Outbox</p>
                            <div className = {classes.SearchBox}>
                                <input className = {classes.Search} type = "text" placeholder = "Search Mail"/>
                                <span className = {['fa fa-search',classes.SearchIcon].join(' ')}></span>
                            </div>
                        </div>
                        <div className = {classes.OptionButtons}>
                            <span className = {classes.Checkbox}>
                                <input className = {classes.Box} type = "checkbox"/>
                            </span>&nbsp;
                            <span className = {["fa fa-trash-o", classes.TrashButton].join(' ')}></span>
                            <div className = {classes.Paginate}>
                                <span className = {classes.Numbers}>1-10/100</span>&nbsp;
                                <span className = {['fa fa-angle-left',classes.Arrows].join(' ')}></span>&nbsp;
                                <span className = {['fa fa-angle-right',classes.Arrows].join(' ')}></span>
                            </div>
                        </div>
                        {OutboxTemplate}
                    </div>
                </div>
            </div>
        );
    }
}

export default withRouter(Outbox);