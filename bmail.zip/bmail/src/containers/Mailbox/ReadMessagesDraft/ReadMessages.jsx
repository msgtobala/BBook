import React , { Component } from 'react';

import classes from './ReadMessages.css';
import FolderElement from '../../../components/Mailbox/Inbox/FolderElements/FolderElement';
import CatagoryElement from '../../../components/Mailbox/Inbox/CatagoryElements/CatagoryElements';

class ReadMessages extends Component {
    state = {
        folders: [
            {name: 'Inbox', icon: 'fa fa-inbox', to: '/dashboard/inbox'},
            {name: 'Sent', icon: 'fa fa-envelope-o',to: '/dashboard/outbox'},
            {name: 'Draft', icon:'fa fa-file-text-o',to: '/dashboard/draft'},
            {name: 'Trash',icon: 'fa fa-trash-o',to: '/dashboard/trash'}
        ],
        catagories : [
            {name: 'Important',icon: 'fa fa-circle-o',to: '/dashboard/important',color:'#dd4b39'},
            {name: 'Pinned',icon: 'fa fa-circle-o',to: '/dashboard/pinned',color: '#f39c12 '},
            {name: 'Starred',icon: 'fa fa-circle-o',to: '/dashboard/starred',color: '#3c8dbc'}
        ],
        messages: [
            {id: '1',icon: 'fa fa-star-o',from: 'Balaji Venkatraman',subject:'Greetings',body: 'Hai hello feel free to use Bmail',to:'/'},
            {id: '2',icon: 'fa fa-star-o',from: 'Balaji',subject:'Greetings From Bmail Team',body:'Hai hello feel free to use Bmail.It is absolutely free and you can use it where ever you are',to:'/'},
            {id: '3',icon: 'fa fa-star-o',from: 'Bala',subject:'Greetings',body: 'Hai',to:'/'}
        ],
        currMessage: null,

    }

    componentDidMount() {
        let query = new URLSearchParams(this.props.location.search);
        let messages = this.state.messages;
        let currMessages;
        let mailId = null;
        for(let param of query.entries()){
            mailId = param[1];
        }
        console.log(mailId);
        for(let itr in this.state.messages){
            if(messages[itr].id === mailId){
                currMessages = messages[itr]
            }
        }
        console.log(currMessages)
        console.log(currMessages);
        this.setState({currMessage:currMessages})
    }
    render () {
        let folderTemplate = (
            this.state.folders.map(ele => (
                <FolderElement 
                            key = {ele.name}
                            icon = {ele.icon}
                            name = {ele.name}
                            toLink = {ele.to}/>
            ))
        );
        
        let catagoryTemplate = (
            this.state.catagories.map(ele=>(
                <CatagoryElement 
                            key = {ele.name}
                            icon = {ele.icon}
                            name = {ele.name}
                            toLink = {ele.to}
                            color = {ele.color}/>
            ))
        );
        return (
            <div className = {classes.ReadMessages}>
                <div className = {classes.Panel}>
                    <p className = {classes.Dashboard}>Read Messages</p>
                </div>
                <div className = {classes.Pagination}>
                  <span
                      style = {{fontSize: '12px',
                                margin: '0px 8px'
                              }} 
                      className = {"fa fa-dashboard"}></span>
                  <span className = {classes.Crumbs}><span className = {classes.Home}>Inbox</span> > Read Messages</span>
                </div>
                <div className = {classes.MessageContents}>
                    <div className = {classes.Folders}>
                        <button className = {classes.Compose}>Compose</button>
                        <div className = {classes.FolderBox}>
                            <p className = {classes.FolderTitle}>Folders
                                <span className = {['fa fa-plus',classes.Expand].join(' ')}></span>
                            </p>
                            {folderTemplate}
                        </div>
                        <div className = {classes.FolderBox}>
                            <p className = {classes.FolderTitle}>Catagories
                                <span className = {['fa fa-plus',classes.Expand].join(' ')}></span>
                            </p>
                            {catagoryTemplate}
                        </div>
                    </div>
                    <div className = {classes.MessageSection}>
                        <div className = {classes.InboxHeading}>
                            <p className = {classes.InboxHead}>Read Mail</p>
                        </div>
                        <div className = {classes.SubjectSection}>
                            <p className = {classes.Sub}>Subject: Message Subject Here</p>
                            <p className = {classes.From}>From: rslbalaji@bmail.com {this.state.messages.from}<span className = {classes.Date}>15 Feb,2018 2:34PM</span></p>
                        </div>
                        <div className = {classes.Controls}>
                            <div>
                                <span className = {['fa fa-trash',classes.ControlIcons].join(' ')}></span>
                                <span className = {['fa fa-mail-reply',classes.ControlIcons].join(' ')}></span>
                                <span className = {['fa fa-mail-forward',classes.ControlIcons].join(' ')}></span>
                            </div>
                            <div>
                                <span className = {['fa fa-star-o',classes.Star].join(' ')}></span>
                                <span className = {['fa fa-map-pin',classes.Pin].join(' ')}></span>
                                <span className = {['fa fa-info-circle',classes.Important].join(' ')}></span>
                            </div>
                        </div>
                        <div className = {classes.MessageBody}>
                              Body appear here
                        </div>
                        <div className = {classes.ButtonControls}>
                            <button className = {classes.ButtonControl}>
                                <span className = {['fa fa-trash',classes.ControlIco].join(' ')}></span> Trash
                            </button>
                            <button className = {classes.ButtonControl}>
                                <span className = {['fa fa-mail-reply',classes.ControlIco].join(' ')}></span> Reply
                            </button>
                            <button className = {classes.ButtonControl}>
                                <span className = {['fa fa-mail-forward',classes.ControlIco].join(' ')}></span> Forward
                            </button>
                        </div>
                    </div>  
                </div>
            </div>
        );
    }
}

export default ReadMessages;