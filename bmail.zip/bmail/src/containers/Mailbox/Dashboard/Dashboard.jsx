import React, { Component } from 'react';
import { Route, Switch } from 'react-router-dom';

import Layout from '../../../components/Mailbox-Layout/Layout';
import DashboardElement from './DashboardElement/DashboardElement';
import Inbox from '../Inbox/Inbox';
import Draft from '../Draft/Draft';
import Outbox from '../Outbox/Outbox';
import Trash from '../Trash/Trash';
import Profile from '../../General/Profile/Profile';
import ReadMessageInbox from '../ReadMessagesInbox/ReadMessages';
import ReadMessageOutbox from '../ReadMessagesOutbox/ReadMessages';
import ReadMessageDraft from '../ReadMessagesDraft/ReadMessages';
import Compose from '../Compose/Compose';

class Dashboard extends Component {
    state = {
        navigations: [
            {icon: 'fa fa-dashboard',name: 'dashboard', displayName: 'Dashboard', to: "/dashboard"},
            {icon: 'fa fa-envelope',name: 'inbox', displayName: 'Inbox',to: "/dashboard/inbox"},
            {icon: 'fa fa-envelope-open',name: 'draft', displayName: 'Draft',to: "/dashboard/draft"},
            {icon: 'fa fa-send',name: 'outbox', displayName: 'Outbox',to: "/dashboard/outbox"},
            {icon: 'fa fa-trash',name: 'trash', displayName: 'Trash',to: "/dashboard/trash"}
        ],
        catagories: [
            {icon: 'fa fa-info',catagory: 'important', displayName: 'Important',to: '/', color: '#dd4936'},
            {icon: 'fa fa-map-pin',catagory: 'pinned', displayName: 'Pinned',to: '/', color: 'white'},
            {icon: 'fa fa-star', catagory: 'starred', displayName: 'Starred', to: '/', color: 'gold'}
        ],
        NotificationLinks: [
            {icon: 'fa fa-envelope-o',to: '/', name: 'New Messages'},
            {icon: 'fa fa-bell-o',to: '/', name: 'Alerts'},
            {icon: 'fa fa-flag-o',to: '/', name: 'Flags'},
        ],
        cogs: [
            {icon: 'fa fa-cogs',to: '/', name: 'Settings'}
        ],
        mailTypes: [
            {cnt: null,setName:'mails',icon: 'fa fa-envelope-o',name: 'New Mails',color: '#00c0ef', to: '/dashboard/inbox'},
            {cnt: null,setName:'sent',icon: 'fa fa-envelope-open-o',name: 'Read Mails',color: '#00a65a', to: '/dashboard/inbox'},
            {cnt: null,setName:'draft',icon: 'fa fa-paper-plane-o',name: 'Sent Mails',color: '#f39c12', to:'/dashboard/outbox'},
            {cnt: 0,setName:'trash',icon: 'fa fa-inbox',name: 'Draft Mails',color: '#dd4b39',to:'/dashboard/draft'}
        ],
        catagoryTypes: [
            {icon:'fa fa-info',name: 'Important',color: '#dd4b39'},
            {icon:'fa fa-map-pin',name: 'Pinned',color: '#3c8dbc '},
            {icon:'fa fa-star',name: 'Starred',color: '#00a65a'}
        ],
        achievements: [
            {count: 1,name: 'Starter',starts: 1},
            {count: 100,name: 'Dreamer', starts: 2},
            {count: 500,name: 'Rocker', starts: 3},
            {count: 1000,name: 'King Man',starts: 4},
            {count: 5000,name: 'The God',starts: 5}
        ],
        allAccounts: null,
        authUser: false,
        authId: null,
        currUser: {},
        allMails: null
    }

    componentDidMount() {
        let authUser = false;
        let authId = null;
        let query = new URLSearchParams(this.props.location.search);
        for(let param of query.entries()){
            if(param[0] !== null && param[0] === 'authUser'){
                authUser = param[1];
            }else if(param[0] !== null && param[0] === 'authId'){
                authId = param[1];
            }else if (param[0] === null) {
                this.props.history.push({
                    pathname: '/signin',
                    hash: '#signin'
                })
            }
        }
        let sessionAuthUser  = window.sessionStorage.getItem('authUsr');
        let allUsers = window.sessionStorage.getItem('user');
        let allMessages = window.sessionStorage.getItem('messages');
        allUsers =JSON.parse(allUsers);
        allMessages = JSON.parse(allMessages);
        console.log(sessionAuthUser,allMessages,allUsers);
        if(sessionAuthUser === 'false' || authUser === 'false' || authId === 'null' || +authId > allUsers.length){
            this.props.history.push({
                pathname: '/signin',
                hash: '#signin'
            })
        }else{
            this.setState({authUser: authUser, authId: authId, allAccounts: allUsers,allMails: allMessages},()=> {
                console.log(this.state.authUser,this.state.authId,this.state.allAccounts,this.state.allMails);
            });
        }
        // let sessionAuthUser = window.sessionStorage.getItem('authUsr');
        // let users = window.sessionStorage.getItem('user');
        // let messages = window.sessionStorage.getItem('messages');
        // messages = JSON.parse(messages);
        // users = JSON.parse(users);
        // let query = new URLSearchParams(this.props.location.search);
        // let authUser = false;
        // let authId = null;
        // let currUserAcc = null;
        // let updatedMailTypes = this.state.mailTypes;
        // for(let param of query.entries()){
        //     if(param[0] === 'authUser' && param[0] !== null){
        //         authUser = param[1];
        //     }else if(param[0] === 'authId' && param[0] !== null){
        //         authId = param[1];
        //     }
        // }
        // currUserAcc = messages[+authId];
        // if(authId === 'null' || authUser === 'false' || sessionAuthUser === 'false' || +authId > users.length){
        //     console.log(authUser)
        //     this.props.history.push({
        //         pathname: '/signin',
        //         hash: 'signin'
        //     })
        // }else{
        //     if(currUserAcc !== null || currUserAcc !== undefined){
        //         let i = 0;
        //         for(let itr in currUserAcc){
        //             if(itr === 'mails' || itr === 'sent' || itr === 'draft' || itr === 'trash'){
        //                 let len = currUserAcc[itr].length;
        //                 updatedMailTypes[i].cnt = len;
        //                 i++;
        //             }
        //         }
        //     }
        //     this.setState({allMessages: messages,mailTypes:updatedMailTypes,authId: authId,authUser: authUser,accounts: users,currUser: currUserAcc}, ()=> {
        //         console.log(this.state.authId,this.state.authUser,this.state.accounts,this.state.currUser);
        //     })
        // }
   }

    sendMailHandler = (email,subject,body) => {
        let allAccounts = this.state.allAccounts;
        let allMessages = this.state.allMails;
        let inboxId = null;
        let stateId = +this.state.authId;
        let outboxId = null;
        let recipentEmail = null;
        for(let itrId in allAccounts){
            if(allMessages[itrId].email === email){
                inboxId = itrId;
            }
        }
        for(let itrId in allAccounts){
            if(allMessages[itrId].id === stateId){
                outboxId = itrId;
                recipentEmail = allMessages[itrId].email;
            }
        }
        let outboxMessages = allMessages[outboxId];
        let inboxMessages = allMessages[inboxId];
        let sentbox = outboxMessages['sent'];
        let inbox = inboxMessages['mails'];
        let date = new Date();
        let d = date.getDate() + '/' + date.getMonth()+ '/'+ date.getFullYear() + ' ' + date.getHours() + ':' + date.getMinutes()
        let newMail = {
            id: sentbox.length + 1,
            icon: 'fa fa-star-o',
            email: email,
            date: d,
            subject: subject,
            body: body,
            status: 'Unread',
            important: false,
            starred: false,
            pinned: false,
            locked: false
        }

        let recipientnewMail = {
            id: inbox.length + 1,
            icon: 'fa fa-star-o',
            email: recipentEmail,
            date: d,
            subject: subject,
            body: body,
            status: 'Unread',
            important: false,
            starred: false,
            pinned: false,
            locked: false
        }
        
        sentbox.push(newMail);
        outboxMessages['sent'] = sentbox;
        allMessages[inboxId] = outboxMessages;

        inbox.push(recipientnewMail);
        inboxMessages['mails'] = inbox;
        allMessages[outboxId] = inboxMessages;

        
        sessionStorage.setItem('messages',JSON.stringify(allMessages));
        this.setState({allMails: allMessages},()=>{
                console.log(this.state.allMails);
        });
        this.props.history.push({
            pathname: '/dashboard/inbox',
            search: '#inbox'
        })
    }
    
    draftMailHandler = (email,subject,body) => {
        console.log(email)
        let allAccounts = this.state.allAccounts;
        let allMessages = this.state.allMails;
        let stateId = +this.state.authId;
        let draftId = null;
        for(let itrId in allAccounts){
            if(allMessages[itrId].id === stateId){
                draftId = itrId;
            }
        }
        let draftMessages = allMessages[draftId];
        let draft = draftMessages['draft'];
        let newMessage = {
            id: draft.length + 1,
            icon: 'fa fa-star-o',
            email: email,
            subject: subject,
            body: body,
            status: 'Unread',
            important: false,
            starred: false,
            pinned: false,
            locked: false
        }
        draft.push(newMessage);
        draftMessages['draft'] = draft;
        allMessages[draftId] = draftMessages;
        console.log(allMessages)
        sessionStorage.setItem('messages',JSON.stringify(allMessages))
        this.setState({allMails: allMessages},()=>{
            console.log(this.state.allMails);
        });
        this.props.history.push({
            pathname: '/dashboard/draft',
            search: '#draft'
         })
    }

    render () {
        return (
            <Layout 
                navigation = {this.state.navigations}
                catagories = {this.state.catagories}
                notificationlinks = {this.state.NotificationLinks}
                cogs = {this.state.cogs}>
                <Switch>
                    <Route exact path = "/dashboard" render = {()=>(<DashboardElement 
                                                                 catagoryTypes = {this.state.catagoryTypes}
                                                                 mailTypes = {this.state.mailTypes}
                                                                 messages = {this.state.currUser}/>)}/>
                    <Route exact path = "/dashboard/inbox" render = {()=>(<Inbox 
                                                                 authId = {this.state.authId}/>)} />
                    <Route exact path = "/dashboard/draft" component = {()=>(<Draft
                                                                 authId = {this.state.authId}/>)} />
                    <Route exact path = "/dashboard/outbox" component = {()=>(<Outbox
                                                                 authId = {this.state.authId}/>)}/>
                    <Route exact path = "/dashboard/trash" component = {()=>(<Trash
                                                                 authId = {this.state.authId}/>)} />
                    <Route exact path = "/dashboard/profile" component = {Profile}/>
                    <Route exact path = "/dashboard/inbox/readmessages" component = {()=>(<ReadMessageInbox
                                                                        authId = {this.state.authId}/>)} />
                    <Route exact path = "/dashboard/outbox/readmessages" component = {ReadMessageOutbox} />
                    <Route exact path = "/dashboard/draft/readmessages" component = {ReadMessageDraft} />
                    <Route exact path = "/dashboard/trash/readmessages" component = {ReadMessageOutbox} />
                    <Route exact path = "/dashboard/compose" render = {()=>(<Compose
                                                                    sendMail = {this.sendMailHandler}
                                                                    draftMail = {this.draftMailHandler}
                                                                    authUser = {this.state.authUser}
                                                                    authId = {this.state.authId}/>)}/>
                </Switch>
            </Layout>
        );
    }
}

export default Dashboard;