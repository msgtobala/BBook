import React from 'react';
import { Link } from 'react-router-dom';

import classes from './DashboardElement.css';
import DashboardBoxes from '../../../../components/Mailbox/Dashboard/DashboardBoxes/DashboardBoxes';
import CatagoryBoxes from '../../../../components/Mailbox/Dashboard/CatagoryBoxes/CatagoryBoxes';
import Avatar from '../../../../assets/Images/avatar.png';
import Star from '../../../../components/Mailbox/Dashboard/Stars/Starts'

const DashboardElement = (props) => {
    let messageArray = props.messages;
    console.log(Object.keys(messageArray).length)
    let mailTypeArray = props.mailTypes;
    let catagoryArray = props.catagoryTypes;
    let stars = 2;
    let starObj = [];
    for(let itr = 0;itr < 5; itr++){
        if(itr<stars){
            starObj.push({starType:'filled',id:itr})
        }else{
            starObj.push({starType:'unfilled',id: itr})
        }
    }
    let mailTypesTemplate = (
        mailTypeArray.map(ele=>(
            <DashboardBoxes
                        key = {ele.name} 
                        icon = {ele.icon}
                        name = {ele.name}
                        color = {ele.color}
                        toLink = {ele.to}
                        count = {ele.cnt}/>
        ))
    );
    let catagoryArrayTemplate = (
        catagoryArray.map(ele=>(
            <CatagoryBoxes 
                       key = {ele.name}
                       icon = {ele.icon}
                       name = {ele.name}
                       color = {ele.color}/>
        ))
    );
    let starTemplate = (
        starObj.map(ele=>(
            <Star
                key = {ele.id}
                startType = {ele.starType}/>
        ))
    )
    return (
        <div className = {classes.DashboardElement}>
            <div className = {classes.Panel}>
                <p className = {classes.Dashboard}>Dashborad<span className = {classes.ControlPanel}> Control Panel</span></p>
            </div>
            <div className = {classes.Pagination}>
                <span
                     style = {{fontSize: '12px',
                               margin: '0px 8px'
                             }} 
                     className = {"fa fa-home"}></span>
                <span className = {classes.Crumbs}><span className = {classes.Home}>Home</span> > Dashboard</span>
            </div>
            <h1 className = {classes.MailTypes}>Mail Types</h1>
            <div className = {classes.DashboardBoxes}>
                {mailTypesTemplate}
            </div>
            <h1 className = {classes.MailTypes}>Catagory Mails</h1>
            <div className = {classes.CatagoryBoxes}>
                {catagoryArrayTemplate}
            </div>
            <h1 className = {classes.Types}>My Achievements</h1>
            <div className = {classes.Achievements}>
              <div className = {classes.AchievementDetail}>
                  <p>Total Mails Sent: <span style = {{fontWeight: 'bold'}}>08</span></p>
                  <br/>
                  <p>Total Mails Got: <span style = {{fontWeight: 'bold'}}>12</span></p>
              </div>
              <div className = {classes.AchievementLogo}>
                 <span className = {['fa fa-trophy',classes.Trophy].join(' ')}></span>
              </div>
              <div className = {classes.Profile}>
                <div className = {classes.Namecard}>
                    <div className = {classes.Avatar}>
                         <img className = {classes.AvatarImage} src = {Avatar}  alt = "avatar"/>
                     </div>
                     <div className = {classes.NameDetails}>
                         <p className = {classes.Name}>Balaji Venkatraman</p>
                         <span className = {classes.Online}>
                             Dreamer
                         </span>
                     </div>
                     {starTemplate}
                     <Link to = {{
                         pathname: "/dashboard/profile",
                         hash:'#profile'
                     }}className = {classes.ViewProfile}>ViewProfile 
                        <span className = {['fa fa-arrow-circle-right',classes.View].join(' ')}></span>
                     </Link>
                </div>
              </div>
            </div>
        </div>
    );
}

export default DashboardElement;